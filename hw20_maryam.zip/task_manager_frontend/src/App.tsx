
import AppRouter from './AppRouter'
import './index.css'

function App() {

  return (
   <AppRouter/>
  )
}

export default App
